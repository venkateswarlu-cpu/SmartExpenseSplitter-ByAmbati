import axios from "axios";

const API_URL = "http://localhost:5000/api"; // Backend URL

export const getSettlement = async (groupId) => {
  try {
    const res = await axios.get(`${API_URL}/settlements/${groupId}`);
    return res.data;
  } catch (err) {
    console.error(err);
    throw err;
  }
};
