import React, { useState } from "react";
import ExpenseForm from "../components/ExpenseForm";
import ExpenseList from "../components/ExpenseList";
import Settlement from "../components/Settlement";

const Home = () => {
  const groupId = "sample-group-1"; // Sample ID
  const [refresh, setRefresh] = useState(0);

  const handleRefresh = () => setRefresh((prev) => prev + 1);

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Smart Expense Splitter</h1>
      <ExpenseForm groupId={groupId} onExpenseAdded={handleRefresh} />
      <ExpenseList groupId={groupId} refresh={refresh} />
      <Settlement groupId={groupId} />
    </div>
  );
};

export default Home;
