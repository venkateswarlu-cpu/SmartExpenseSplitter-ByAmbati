import React, { useEffect, useState } from "react";

const Settlement = ({ groupId }) => {
  const [balance, setBalance] = useState({});

  useEffect(() => {
    const expenses = JSON.parse(localStorage.getItem("expenses")) || [];
    const groupExpenses = expenses.filter((e) => e.groupId === groupId);
    const bal = {};

    groupExpenses.forEach((expense) => {
      const payerId = expense.paidBy;
      const participants = expense.participants || [];
      const share = participants.length ? expense.amount / participants.length : 0;

      bal[payerId] = (bal[payerId] || 0) + expense.amount;

      participants.forEach((p) => {
        bal[p] = (bal[p] || 0) - share;
      });
    });

    setBalance(bal);
  }, [groupId]);

  if (Object.keys(balance).length === 0) return <p>No settlement yet.</p>;

  return (
    <div>
      <h3>Settlement</h3>
      <ul>
        {Object.entries(balance).map(([user, amount]) => (
          <li key={user}>
            {user}: {amount.toFixed(2)}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Settlement;
