import React, { useState } from "react";

const ExpenseForm = ({ groupId, onExpenseAdded }) => {
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [paidBy, setPaidBy] = useState("");
  const [participants, setParticipants] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const expense = {
      id: Math.random().toString(36).substr(2, 9),
      groupId,
      description,
      amount: parseFloat(amount),
      paidBy,
      participants: participants.split(",").map((p) => p.trim()),
    };

    // Save to localStorage (temporary demo)
    const existing = JSON.parse(localStorage.getItem("expenses")) || [];
    localStorage.setItem("expenses", JSON.stringify([...existing, expense]));

    setDescription("");
    setAmount("");
    setPaidBy("");
    setParticipants("");
    onExpenseAdded();
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
      <h3>Add Expense</h3>
      <input
        type="text"
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        required
        style={{ marginRight: "5px" }}
      />
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        required
        style={{ marginRight: "5px" }}
      />
      <input
        type="text"
        placeholder="Paid By"
        value={paidBy}
        onChange={(e) => setPaidBy(e.target.value)}
        required
        style={{ marginRight: "5px" }}
      />
      <input
        type="text"
        placeholder="Participants (comma separated)"
        value={participants}
        onChange={(e) => setParticipants(e.target.value)}
        required
        style={{ marginRight: "5px" }}
      />
      <button type="submit">Add Expense</button>
    </form>
  );
};

export default ExpenseForm;
