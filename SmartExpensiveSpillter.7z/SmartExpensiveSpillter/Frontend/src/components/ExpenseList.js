import React, { useEffect, useState } from "react";

const ExpenseList = ({ groupId, refresh }) => {
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    const all = JSON.parse(localStorage.getItem("expenses")) || [];
    setExpenses(all.filter((e) => e.groupId === groupId));
  }, [groupId, refresh]);

  if (expenses.length === 0) return <p>No expenses yet.</p>;

  return (
    <div>
      <h3>Expenses</h3>
      <ul>
        {expenses.map((e) => (
          <li key={e.id}>
            {e.description} - {e.amount.toFixed(2)} (Paid by: {e.paidBy}) | 
            Participants: {e.participants.join(", ")}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExpenseList;
