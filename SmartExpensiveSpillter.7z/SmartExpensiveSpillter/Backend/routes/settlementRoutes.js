// backend/routes/settlementRoutes.js
import express from "express";
import { getSettlement } from "../controllers/settlementController.js";

const router = express.Router();

// GET settlement for a specific group
router.get("/:groupId", getSettlement);

export default router;
