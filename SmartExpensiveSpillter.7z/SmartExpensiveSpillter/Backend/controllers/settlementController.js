// backend/controllers/settlementController.js
import Expense from "../models/Expense.js"; // Make sure Expense.js exists

// Named export
export const getSettlement = async (req, res) => {
  try {
    const { groupId } = req.params;

    // Find all expenses for the group
    const expenses = await Expense.find({ groupId })
      .populate("paidBy")           // Assuming paidBy is a reference
      .populate("participants.user"); // Assuming participants have a user reference

    const balance = {};

    expenses.forEach((expense) => {
      const payerId = expense.paidBy?._id?.toString();
      const participants = expense.participants || [];
      const share = participants.length ? expense.amount / participants.length : 0;

      // Add total paid by payer
      if (payerId) {
        balance[payerId] = (balance[payerId] || 0) + expense.amount;
      }

      // Subtract each participant's share
      participants.forEach((p) => {
        const userId = p.user?._id?.toString() || p.user;
        if (!userId) return;
        balance[userId] = (balance[userId] || 0) - share;
      });
    });

    res.status(200).json({ success: true, balance });
  } catch (error) {
    console.error("Settlement Controller Error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to calculate settlement",
      error: error.message,
    });
  }
};
