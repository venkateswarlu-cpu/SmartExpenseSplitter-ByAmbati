import Group from "../models/Group.js";
import Expense from "../models/Expense.js";

// Create a new group
export const createGroup = async (req, res) => {
  try {
    const group = await Group.create(req.body);
    res.status(201).json(group);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get all groups
export const getGroups = async (req, res) => {
  try {
    const groups = await Group.find().populate("members");
    res.status(200).json(groups);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get single group by ID
export const getGroupById = async (req, res) => {
  try {
    const group = await Group.findById(req.params.id)
      .populate("members")
      .populate({
        path: "expenses",
        populate: { path: "paidBy participants.user" }
      });

    if (!group) return res.status(404).json({ message: "Group not found" });

    res.status(200).json(group);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
