import Expense from "../models/Expense.js";
import Group from "../models/Group.js";


export const addExpense = async (req, res) => {
  try {
    const expense = await Expense.create(req.body);

    await Group.findByIdAndUpdate(req.body.groupId, {
      $push: { expenses: expense._id },
    });

    res.status(201).json(expense);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get Expenses of a Group
export const getExpensesByGroup = async (req, res) => {
  try {
    const expenses = await Expense.find({ groupId: req.params.groupId })
      .populate("paidBy")
      .populate("participants.user");

    res.status(200).json(expenses);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
