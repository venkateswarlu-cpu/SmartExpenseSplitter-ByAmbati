import Expense from "../models/Expense.js";

export const getSettlement = async (req, res) => {
  const groupId = req.params.groupId;

  const expenses = await Expense.find({ groupId });

  let balanceSheet = {};

  expenses.forEach((exp) => {
    // payer gets positive
    balanceSheet[exp.paidBy] = (balanceSheet[exp.paidBy] || 0) + exp.amount;

    // participants get negative
    exp.participants.forEach((p) => {
      balanceSheet[p.user] = (balanceSheet[p.user] || 0) - p.share;
    });
  });

  let payers = [];
  let receivers = [];

  for (let user in balanceSheet) {
    if (balanceSheet[user] < 0)
      payers.push({ user, amount: -balanceSheet[user] });
    else receivers.push({ user, amount: balanceSheet[user] });
  }

  let settlements = [];

  payers.sort((a, b) => b.amount - a.amount);
  receivers.sort((a, b) => b.amount - a.amount);

  let i = 0,
    j = 0;

  while (i < payers.length && j < receivers.length) {
    let pay = Math.min(payers[i].amount, receivers[j].amount);

    settlements.push({
      from: payers[i].user,
      to: receivers[j].user,
      amount: pay
    });

    payers[i].amount -= pay;
    receivers[j].amount -= pay;

    if (payers[i].amount === 0) i++;
    if (receivers[j].amount === 0) j++;
  }

  res.json(settlements);
};
