import mongoose from "mongoose";

const expenseSchema = mongoose.Schema(
  {
    groupId: { type: mongoose.Schema.Types.ObjectId, ref: "Group" },
    description: String,
    amount: Number,
    paidBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    participants: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        share: Number
      }
    ],
    category: String
  },
  { timestamps: true }
);

export default mongoose.model("Expense", expenseSchema);
